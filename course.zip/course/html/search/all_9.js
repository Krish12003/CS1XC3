var searchData=
[
  ['name_0',['name',['../struct__course.html#a8a6f7d2171f18b5d13e86913345f381d',1,'_course']]],
  ['name_2etxt_1',['name.txt',['../name_8txt.html',1,'']]],
  ['num_5fgrades_2',['num_grades',['../struct__student.html#a6592ee968ed2226737f45243e7602636',1,'_student']]]
];
